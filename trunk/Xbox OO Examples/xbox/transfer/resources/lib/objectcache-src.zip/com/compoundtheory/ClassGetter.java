package com.compoundtheory;

/**
 * This is just for finding out neat things about CF
 * @author Mark Mandel
 *
 */
public class ClassGetter
{
	public static Class getMyClass(Object o)
	{
		return o.getClass();
	}
}
