package com.compoundtheory.objectcache;

import java.lang.ref.SoftReference;

import coldfusion.runtime.TemplateProxy;

public interface ICacheManager
{
	/**
	 * Pops a CFC off the Discard Queue,  
	 * @return The CFC that was poped
	 */
	public TemplateProxy popFromDiscardQueue();

	/**
	 * If the DiscardQueue is empty or not
	 * @return If the queue is empty
	 */
	public boolean discardQueueIsEmpty();

	/**
	 * How many objects are in the discard queue
	 * @return the size() of the discard queue
	 */
	public int discardQueueSize();
	
	/**
	 * Whether the CFC has been cached
	 * @param clazz The class of CFC
	 * @param cfc The CFC to check for
	 * @return If it exists in a cache
	 */
	public boolean has(String clazz, TemplateProxy cfc);

	/**
	 * Whether the CFC has been cached
	 * @param clazz The class of CFC
	 * @param key The key the CFC is stored under
	 * @return If it exists in a cache
	 */
	public boolean has(String clazz, String key);

	/**
	 * Retrieve a CFC from the cache
	 * @param clazz The clas of the CFC
	 * @param key The key it was stored under
	 * @return The CFC itself
	 * @throws ObjectNotFoundException if the object doesn't exist in the cache
	 */
	public TemplateProxy get(String clazz, String key)
			throws ObjectNotFoundException;

	/**
	 * Adds an object to to the cache
	 * @param clazz The class of the object
	 * @param key The key of the object
	 * @param softRef The soft reference containing the CFC
	 */
	public void add(String clazz, String key, SoftReference softRef);

	/**
	 * Discard the object from the cache
	 * @param clazz the class of the object
	 * @param cfc the cfc to discard
	 */
	public void discard(String clazz, TemplateProxy cfc);
	
	/**
	 * Reap off a cleared soft reference
	 * @param clazz the class to reap to
	 * @param softRef the soft reference to reap
	 */	
	public void reap(String clazz, SoftReference softRef);

}