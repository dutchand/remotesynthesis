package com.compoundtheory.objectcache;

import java.util.*;
import java.lang.ref.*;
import coldfusion.runtime.*;


/**
 * Object for persisting ColdFusion CFCs
 * @author Mark Mandel
 *
 */
public class ObjectCache extends Observable
{
	private Map cache;
	private Map lookup;
	private Map hashLookup;
	private int maxNumber;
	private int secondsPersisted;
	private int requestCycle;
	//pool for getting cache wrappers 
	private CachedObjectPool cachedObjectPool;
	private String className;
	
	
	private static final int GC_CYCLE_RATE = 10;
	
	/**
	 * Default constructor of unlimitde objects, and always persisted
	 */
	public ObjectCache(String className)
	{
		this(className, 0, 0);
	}
	
	/**
	 * Constructor for a new Object Cache
	 * @param maxNumber Maximum number of objects to cache. 0 is unlimited
	 * @param secondsPersisted Total number of seconds to persist an object. 0 is forever.
	 */
	public ObjectCache(String className, int maxNumber, int secondsPersisted)
	{
		setMaxNumber(maxNumber);
		setSecondsPersisted(secondsPersisted);
		setRequestCycle(0);
		setCachedObjectPool(new CachedObjectPool(10,10));
		setClassName(className);
		
		if(getMaxNumber() > 0)
		{
			setCache(Collections.synchronizedMap(new HashMap(getMaxNumber())));
			setLookup(Collections.synchronizedMap(new HashMap(getMaxNumber())));
			setHashLookup(Collections.synchronizedMap(new HashMap(getMaxNumber())));
		}
		else
		{
			setCache(Collections.synchronizedMap(new HashMap()));
			setLookup(Collections.synchronizedMap(new HashMap()));			
			setHashLookup(Collections.synchronizedMap(new HashMap()));
		}
	}
	
	/**
	 * If the cache has the object, and it hasn't expired
	 * @param object The CFC object to check for
	 * @return whether the object exists, and hasn't expired
	 */
	public boolean has(TemplateProxy object)
	{
		String hash = Integer.toString(System.identityHashCode(object));
		if(!getLookup().containsKey(hash))
		{
			return false;
		}
		
		return has((String)getLookup().get(hash));
	}
	
	/**
	 * If the cache has the object, and it hasn't expired
	 * @param key The key to look for the object is stored under
	 * @return whether the object exists, and hasn't expired
	 */
	public boolean has(String key)
	{
		if(!getCache().containsKey(key))
		{
			return false;
		}
		
		CachedObject object = getCachedObject(key);
		
		if(!object.hasExpired() && object.getCFC() != null)
		{
			return true;
		}
		return false;
	}
	
	/**
	 * Retrieve an object from the cache
	 * @param key The key to look for
	 * @return The CFC that was stored in here
	 * @throws ObjectNotFoundException If the object doesnt exist in the cache, this is thrown
	 */
	public TemplateProxy get(String key)
	throws ObjectNotFoundException
	{
		incrementRequestCycle();
		checkRunGarbageCollect();		
		
		if(!has(key))
		{
			throw new ObjectNotFoundException("Object under '"+ key +"' not found in this cache, or it may have expired");
		}
		
		CachedObject cacheobject = getCachedObject(key);
		TemplateProxy cfc = cacheobject.getCFC();
		
		if(cacheobject.getCFC() == null)
		{
			throw new ObjectNotFoundException("Object under '"+ key +"' has been picked up by the JVM gabarge collector");
		}
		
		cacheobject.incrementHits();
		
		return cfc;
	}
	
	/**
	 * Adds an object to the cache
	 * @param softRef the soft reference that contains the object
	 * @param key The key to store it under. This should be unique
	 */
	public void add(SoftReference softRef, String key)
	{
		//first make sure it's real
		TemplateProxy object = (TemplateProxy)softRef.get();
		
		if(object == null)
		{
			return;
		}
		
		//discard object if the key exists
		if(has(key))
		{
			pushToDiscardQueue(getRealObject(key));
		}
		
		//add the object
		String hash = Integer.toString(System.identityHashCode(object));
		
		//grab a cachedObject from the cache, and configure
		CachedObject cachedObject = getCachedObjectPool().getCachedObject();
		
		cachedObject.configure(softRef, getSecondsPersisted());
		
		getHashLookup().put(softRef, hash);
		getLookup().put(hash, key);
		getCache().put(key, cachedObject);
		
		incrementRequestCycle();
		//make this do checking on how many currently exist
		checkRunGarbageCollect();
	}
	
	/**
	 * Discards the object from the cache
	 * @param object the object to remove
	 */
	public void discard(TemplateProxy object)
	{
		if(has(object))
		{
			String hash = Integer.toString(System.identityHashCode(object));
			
			discard(hash);
		}
	}
	
	/**
	 * Just discard from a hash value
	 * @param hash the identityHashCode of the original object
	 */
	private void discard(String hash)
	{
		String key = (String)getLookup().get(hash);
		
		CachedObject cachedObject = getCachedObject(key);
		
		getLookup().remove(hash);
		getCache().remove(key);
		
		//recycle cachedObject wrapper
		if(cachedObject != null) //just make sure
		{
			getCachedObjectPool().recycle(cachedObject);
		}
	}
	
	/**
	 * Pushes the file out to an observer
	 * so it's ready to be discarded as 
	 * the system comes around to it.
	 * 
	 * @param cfc the CFC to push to the discard queue for processing 
	 */
	private void pushToDiscardQueue(TemplateProxy cfc)
	{
		if(cfc != null)
		{
			setChanged();
			notifyObservers(cfc);
		}
	}
	
	/**
	 * Checks to see if the garbage collection
	 * should be run, and runs it as neccessary
	 */
	private void checkRunGarbageCollect()
	{
		if(getRequestCycle() > GC_CYCLE_RATE)
		{
			//run garbage collect
			setRequestCycle(0);
			GarbageCollect gc = new GarbageCollect();
			gc.start();
		}
	}	
	

	/**
	 * Reaps out the soft ref required
	 * @param softRef the soft ref that has been cleared
	 */
	public void reap(SoftReference softRef)
	{
		if(getHashLookup().containsKey(softRef))
		{
			String hash = (String)getHashLookup().get(softRef);
			getHashLookup().remove(softRef);
			discard(hash);
		}
	}
	
	private TemplateProxy getRealObject(String key)
	{
		return getCachedObject(key).getCFC();
	}
	
	private CachedObject getCachedObject(String key)
	{
		return (CachedObject)getCache().get(key);
	}

	private Map getCache()
	{
		return cache;
	}

	private void setCache(Map cache)
	{
		this.cache = cache;
	}

	private Map getLookup()
	{
		return lookup;
	}

	private void setLookup(Map lookup)
	{
		this.lookup = lookup;
	}

	private int getMaxNumber()
	{
		return maxNumber;
	}

	private void setMaxNumber(int maxNumber)
	{
		this.maxNumber = maxNumber;
	}

	private int getSecondsPersisted()
	{
		return secondsPersisted;
	}

	private void setSecondsPersisted(int secondsPersisted)
	{
		this.secondsPersisted = secondsPersisted;
	}

	private int getRequestCycle()
	{
		return requestCycle;
	}

	private void setRequestCycle(int requestCycle)
	{
		this.requestCycle = requestCycle;
	}
	
	private void incrementRequestCycle()
	{
		setRequestCycle(getRequestCycle() + 1);
	}
	
	private CachedObjectPool getCachedObjectPool()
	{
		return cachedObjectPool;
	}

	private void setCachedObjectPool(CachedObjectPool cachedObjectPool)
	{
		this.cachedObjectPool = cachedObjectPool;
	}	
	
	private Map getHashLookup()
	{
		return hashLookup;
	}

	private void setHashLookup(Map hashLookup)
	{
		this.hashLookup = hashLookup;
	}	

	private String getClassName()
	{
		return className;
	}

	private void setClassName(String className)
	{
		this.className = className;
	}
	
	/**
	 * Garbage collect class for async collections
	 * Doesn't actually discard objects, pushes them
	 * out to a queue to be discarded by CF
	 * @author Mark Mandel
	 *
	 */
	private class GarbageCollect extends Thread
	{
		public GarbageCollect()
		{
			//nothing much here
		}
		
		/**
		 * Thread method for running the garbage collection process
		 */
		public void run()
		{
			//first, let's expire objects that are expired 
			//gimme a local copy, in AN order

			LinkedList localCache = new LinkedList(getCache().values());
			
			//just escape out if we don't need to expire objects
			if(getSecondsPersisted() != Config.UNLIMITED_SECONDS)
			{
				Iterator iterator = localCache.iterator();
				
				while(iterator.hasNext())
				{
					CachedObject object = (CachedObject) iterator.next();
					
					if(object.hasExpired())
					{
						pushToDiscardQueue(object.getCFC());
					}
				}
			}
			
			/*
			 * now, if we're over the legal number of items, let's
			 * do some smart stuff to get rid of the least used items -
			 * 
			 * Basically, build a roullette wheel, by each object's fitness
			 * and do a random remove until we have removed as many as we should
			 */ 
			if(getMaxNumber() != Config.UNLIMITED_OBJECTS && getMaxNumber() < localCache.size())
			{
				int amount = localCache.size() - getMaxNumber();
				
				for(int counter = 0; counter < amount; counter++)
				{
					CachedObject discardObject = popFromRoulleteWheel(localCache);
					if(discardObject == null)
					{
						System.out.println("ObjectCache ["+ getClassName() +"]: How is the discard object null?");
					}
					else
					{
						pushToDiscardQueue(discardObject.getCFC());
					}
				}
			}
		}
		
		/**
		 * Builds a weighted roullette wheel from a snapshot of the current object's 
		 * fitness's, and then selects one from a spin
		 * @param list The list of objects to remove from
		 * @return The CachedObject that was pop'd
		 */
		private CachedObject popFromRoulleteWheel(LinkedList list)
		{
			long sumFitness = 0;
			int[] fitnessSnapShot = new int[list.size()];
			Iterator iterator = list.iterator();
			
			int counter = 0;
			while(iterator.hasNext())
			{
				CachedObject object = (CachedObject)iterator.next();
				int fitness = object.calculateFitness();
				
				sumFitness += fitness;
				fitnessSnapShot[counter] = fitness;
				counter++;
			}
			
			Double doubleRandValue = new Double(Math.random() * sumFitness);
			
			int randValue = Math.round(doubleRandValue.floatValue());
			
			int currentValue = 0;
			
			iterator = list.iterator();
			
			counter = 0;
			while(iterator.hasNext())
			{
				CachedObject object = (CachedObject)iterator.next();
				currentValue += fitnessSnapShot[counter];
				
				if(currentValue >= randValue)
				{
					iterator.remove();
					return object;
				}
				
				counter++;
			}
			
			return null;  //this is bad, and should not happen
		}
	}
}
