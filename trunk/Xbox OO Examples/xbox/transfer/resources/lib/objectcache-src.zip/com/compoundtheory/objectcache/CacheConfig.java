package com.compoundtheory.objectcache;

import java.util.*;

/**
 * The Config querying service, for looking for specific 
 * configurations for specific classes 
 * @author Mark Mandel
 *
 */
public class CacheConfig
{
	private Config defaultConfig;
	private Map configCollection;
	
	
	public CacheConfig()
	{
		Config config = null;
		try
		{
			config = new Config();
		} catch (InvalidScopeException exc)
		{
			//this could never happen
			System.out.println("Error with creating default config: " + exc.getMessage());
			exc.printStackTrace();
		}
		
		configure(config);
		
	}
	
	/**
	 * Constructor that takes the default config
	 *  
	 * @param config
	 */
	public CacheConfig(Config config)
	{
		configure(config);
	}
	
	/**
	 * Add another config to this mechanism for lookup
	 * @param clazz the class to apply this config to
	 * @param config the Config you want to set
	 */
	public void addConfig(String clazz, Config config)
	{
		getConfigCollection().put(clazz, config);
	}
	
	/**
	 * Gets a config for a class, if it can't be found,
	 * returns the default one
	 * @param clazz The class to look for
	 * @return the Config for the class 
	 */
	public Config getConfig(String clazz)
	{
		if(!getConfigCollection().containsKey(clazz))
		{
			return getDefaultConfig();
		}
		
		return (Config)getConfigCollection().get(clazz);
		
	}
	
	private void configure(Config config)
	{
		setDefaultConfig(config);
		
		Map configCollection = Collections.synchronizedMap(new HashMap());
		setConfigCollection(configCollection);		
	}

	private Map getConfigCollection()
	{
		return configCollection;
	}

	private void setConfigCollection(Map configCollection)
	{
		this.configCollection = configCollection;
	}

	private Config getDefaultConfig()
	{
		return defaultConfig;
	}

	private void setDefaultConfig(Config defaultConfig)
	{
		this.defaultConfig = defaultConfig;
	}
}
