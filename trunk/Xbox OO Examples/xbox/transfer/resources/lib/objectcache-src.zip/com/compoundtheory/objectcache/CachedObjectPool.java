package com.compoundtheory.objectcache;

import org.apache.commons.collections.*;

/**
 * Object pool for cached object wrappers,
 * as they can be recycled
 * @author Mark Mandel
 *
 */

public class CachedObjectPool
{
	private Buffer fifo;
	private int changeModifier;
	
	/**
	 * Constructor
	 * @param initialCapacity initial amount of CachedObjects to create 
	 * @param changeModifier how many more to create when the queue runs out
	 */
	public CachedObjectPool(int initialCapacity, int changeModifier)
	{
		setChangeModifier(changeModifier);
		
		//setup a sync'd fifo
		UnboundedFifoBuffer fifo = new UnboundedFifoBuffer(initialCapacity);
		setFifo(BufferUtils.synchronizedBuffer(fifo));
		
		addMoreCachedObjects(initialCapacity);
	}
	
	/**
	 * Retrieve a clean CachedObject from the pool
	 * @return a CachedObject
	 */
	public CachedObject getCachedObject()
	{
		if(getFifo().isEmpty())
		{
			addMoreCachedObjects(getChangeModifier());
			return getCachedObject();
		}
		
		return (CachedObject) getFifo().remove();
	}
	
	/**
	 * Recycle a CachedObject back into the pool. Calls 'clean on the object
	 * @param cachedObject the object to recycle
	 */
	public void recycle(CachedObject cachedObject)
	{
		cachedObject.clean();
		getFifo().add(cachedObject);
	}
	
	/**
	 * add an amount of object to the queue
	 * @param amount the number to add
	 */
	private void addMoreCachedObjects(int amount)
	{
		for(int counter = 0; counter < amount; counter++)
		{
			getFifo().add(new CachedObject());
		}
	}

	private int getChangeModifier()
	{
		return changeModifier;
	}

	private void setChangeModifier(int changeModifier)
	{
		this.changeModifier = changeModifier;
	}

	private Buffer getFifo()
	{
		return fifo;
	}

	private void setFifo(Buffer fifo)
	{
		this.fifo = fifo;
	}
}
