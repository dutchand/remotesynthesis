package com.compoundtheory.objectcache;

/**
 * Exception that is thrown when an 
 * Object cannot be found in the cache
 * 
 * @author Mark Mandel
 */
public class ObjectNotFoundException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3392658525644279476L;

	/**
	 * Default constructor. Has the message 'Object not found'
	 */
	public ObjectNotFoundException()
	{
		super("Object not found");
	}
	
	/**
	 * ObjectNotFound exception with a mesasge
	 * @param msg
	 */
	public ObjectNotFoundException(String msg)
	{
		super(msg);
	}
}
