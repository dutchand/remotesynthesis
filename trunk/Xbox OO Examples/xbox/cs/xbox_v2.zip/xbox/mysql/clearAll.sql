﻿delete FROM console;
delete FROM control;
delete FROM accessory;
delete FROM game;
delete FROM relconsoleaccessories;
delete FROM relconsolecontrols;
delete FROM relconsolegames;